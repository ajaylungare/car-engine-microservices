package com.example.Engine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EngineServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EngineServiceApplication.class, args);
	}

}
