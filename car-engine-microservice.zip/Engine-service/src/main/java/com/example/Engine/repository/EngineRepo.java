package com.example.Engine.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Engine.entity.Engine1;

@Repository
 public interface EngineRepo extends JpaRepository<Engine1,Long> {

	Engine1 findByengineid(Long id );

}
