package com.example.Engine.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Engine.entity.Engine1;
import com.example.Engine.repository.EngineRepo;

@Service
public class Engineservice {

	@Autowired
	EngineRepo repo;
	
	public Engine1 saveEngine(Engine1 engine) {
		return repo.save(engine);
	}

	public Engine1 findbyid(Long id) {
		return repo.findByengineid(id);
	}

}
