package com.example.Engine.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Engine.entity.Engine1;
import com.example.Engine.service.Engineservice;

@RestController
@RequestMapping("/engine")
public class Enginecontroller {
	
	@Autowired
	Engineservice service;
	
	@PostMapping("/")
	public Engine1 saveEngine(@RequestBody Engine1 engine) {
		return service.saveEngine(engine);
	}
	
	@GetMapping("/{id}")
	public Engine1 getEngine(@PathVariable Long id) {
		return service.findbyid(id);
	}

}
