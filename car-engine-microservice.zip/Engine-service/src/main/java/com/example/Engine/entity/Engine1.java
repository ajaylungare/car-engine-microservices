package com.example.Engine.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Engine1 {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long engineid;
	private Long engineCC;
	private String fuleType;
	
	
	public Long getEngineid() {
		return engineid;
	}
	public void setEngineid(Long engineid) {
		this.engineid = engineid;
	}
	public Long getEngineCC() {
		return engineCC;
	}
	public void setEngineCC(Long engineCC) {
		this.engineCC = engineCC;
	}
	public String getFuleType() {
		return fuleType;
	}
	public void setFuleType(String fuleType) {
		this.fuleType = fuleType;
	}
	
	
	

}
