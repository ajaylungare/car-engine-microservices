package com.example.Car.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Car.Entity.Car;
import com.example.Car.ResonanceData.carAndEngine;
import com.example.Car.service.carService;

@RestController
@RequestMapping("/car")
public class carController {
	
	@Autowired
	carService cs;
	
	@PostMapping("/")
	public Car savecar(@RequestBody Car car) {
		return cs.saveCar(car);
	}
	
	@GetMapping("/{id}")
	public carAndEngine getCarandEngine(@PathVariable Long id) {
		return cs.CarandEngine(id);
	}
}
