package com.example.Car.service;

import org.apache.catalina.Engine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.Car.Entity.Car;
import com.example.Car.ResonanceData.carAndEngine;
import com.example.Car.ResonanceData.Engine1;
import com.example.Car.repository.carRepository;

@Service
public class carService {
	
	@Autowired
	carRepository cr;
	
	@Autowired
	RestTemplate RestTemplete;

	public Car saveCar(Car car) {
		return cr.save(car);
	}

	public carAndEngine CarandEngine(Long id) {
		
		carAndEngine ce = new carAndEngine();
		
		Car car = cr.findBycarid(id);
		
		
		Engine1 E = RestTemplete.getForObject("http://localhost:8080/engine/"+car.getEngineid(), Engine1.class);
		
		ce.setCar(car);
		ce.setEngine(E);
		
		return ce;
	}

	
	
		
		
	}

	
	


