package com.example.Car.ResonanceData;

import com.example.Car.Entity.Car;

public class carAndEngine {
	
	Car car;
    Engine1 engine;	
	public Car getCar() {
		return car;
	}
	public void setCar(Car car) {
		this.car = car;
	}
	public Engine1 getEngine() {
		return engine;
	}
	public void setEngine(Engine1 engine) {
		this.engine = engine;
	}
	
	
	
	
	
	
	

}
