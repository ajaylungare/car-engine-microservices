package com.example.Car.Entity;

import org.hibernate.annotations.ValueGenerationType;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Car {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long carid;
	private String carName;
	private String carCampany;
	private Long engineid;
	
	
	public Long getCarid() {
		return carid;
	}
	public void setCarid(Long carid) {
		this.carid = carid;
	}
	public String getCarName() {
		return carName;
	}
	public void setCarName(String carName) {
		this.carName = carName;
	}
	public String getCarCampany() {
		return carCampany;
	}
	public void setCarCampany(String carCampany) {
		this.carCampany = carCampany;
	}
	public Long getEngineid() {
		return engineid;
	}
	public void setEngineid(Long engineid) {
		this.engineid = engineid;
	}
	
	
	
}
