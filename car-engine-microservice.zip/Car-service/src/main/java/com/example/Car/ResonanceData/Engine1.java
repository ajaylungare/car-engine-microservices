package com.example.Car.ResonanceData;

public class Engine1 {

	private Long engineid;
	private Long engineCC;
	private String fuleType;
	
	
	public Long getEngineid() {
		return engineid;
	}
	public void setEngineid(Long engineid) {
		this.engineid = engineid;
	}
	
	public Long getengineCC() {
		return engineCC;
	}
	public void setengineCC(Long engineCC) {
		this.engineCC = engineCC;
	}
	public String getFuleType() {
		return fuleType;
	}
	public void setFuleType(String fuleType) {
		this.fuleType = fuleType;
	}
	
	public Engine1(Long engineid, Long engineCC, String fuleType) {
		super();
		this.engineid = engineid;
		this.engineCC = engineCC;
		this.fuleType = fuleType;
	}
	
	public Engine1() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
