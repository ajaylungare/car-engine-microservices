package com.example.Car.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Car.Entity.Car;

@Repository
public interface carRepository extends JpaRepository<Car, Long>{


	Car findBycarid(Long id);

}
